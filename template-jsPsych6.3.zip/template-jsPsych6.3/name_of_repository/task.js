/* 課題に関するコードを以下に書く */
var welcome = {
  type: "html-keyboard-response",
  stimulus: "こんにちは！ この課題は何かキーボードのキーをタイプするとデータを保存して終わります。"
};

/*タイムラインの設定*/
var timeline = [fullscreen,welcome];