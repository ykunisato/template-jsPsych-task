/*タイムラインの実行*/
jatos.onLoad(() => {
  jsPsych.run(timeline);
});